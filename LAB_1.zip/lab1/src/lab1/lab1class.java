package lab1;

public class lab1class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Hello Wolrd");
	}

}
