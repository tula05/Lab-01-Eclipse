/**
 * 
 */
/**
 * @author Tul
 *
 */
module lab1 {
}